import React from 'react';
import bankImage from './images/bankImage.jpg';

function About() {
  return (
    <div className="container text-center mt-5">
      <div className="about-section">
        <h1 className="display-4">About Us</h1>
        <p className="lead mb-4">Discover our banking services and commitment to excellence.</p>
        <div className="row align-items-center">
          <div className="col-md-6 mb-4">
            <img src={bankImage} alt="Banking Services" className="img-fluid rounded shadow" />
          </div>
          <div className="col-md-6 mb-4">
            <p>
              Welcome to Scotia Bank. With over 150 years of experience, we are dedicated to providing exceptional financial services. Our team of experts is here to support you with personalized banking solutions, from everyday transactions to comprehensive financial planning. Explore our range of products and services designed to help you achieve your financial goals.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default About;
