import '@fortawesome/fontawesome-free/css/all.min.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min'; // Import Bootstrap JavaScript
import { MDBFooter } from 'mdb-react-ui-kit';
import React from 'react';
import './Home.css';
import heroImage from './images/banner.jpg'; // Replace with the correct hero image path
import gicImage1 from './images/gicImage1.jpg'; // Replace with your actual image paths
import gicImage2 from './images/gicImage2.jpg';
import gicImage3 from './images/gicImage3.jpg';

const Home = () => {
  return (
    <div>
      {/* Main Banner Section */}
      <section className="banner-section d-flex align-items-center py-5">
        <div className="container text-center">
          <h1 className="display-3 fw-bold mb-4">Welcome to Our Bank</h1>
          <p className="lead mb-4">Join us today and take advantage of our exclusive offers!</p>
          <a href="#" className="btn btn-light btn-lg text-danger fw-bold">Get Started</a>
        </div>
      </section>

      {/* Hero Section */}
      <section className="hero-section py-5">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-md-6">
              <h1 className="display-4 text-danger">Get up to $1,500 in value</h1>
              <p className="lead text-dark">
                "Enjoy a 7.50% promotional interest rate** when you open a Chequing and Savings Amplifier Account. Start saving today!"
              </p>
              <a href="#" className="btn btn-danger btn-lg">Learn More</a>
            </div>
            <div className="col-md-6 text-center">
              <img 
                src={heroImage} 
                alt="Hero Image" 
                className="img-fluid rounded" 
              />
            </div>
          </div>
        </div>
      </section>

      {/* Featured GIC Rates */}
      <section className="gic-rates py-5">
        <div className="container text-center">
          <h2>Featured GIC Rates</h2>
          <div className="row">
            <div className="col-md-4 mb-4">
              <div className="card">
                <img src={gicImage1} className="card-img-top" alt="GIC Rate 1" />
                <div className="card-body bg-danger text-white">
                  <h5>3.90%</h5>
                  <p>On a Non-Redeemable GIC</p>
                </div>
              </div>
            </div>
            <div className="col-md-4 mb-4">
              <div className="card">
                <img src={gicImage2} className="card-img-top" alt="GIC Rate 2" />
                <div className="card-body bg-danger text-white">
                  <h5>4.00%</h5>
                  <p>On a Redeemable GIC</p>
                </div>
              </div>
            </div>
            <div className="col-md-4 mb-4">
              <div className="card">
                <img src={gicImage3} className="card-img-top" alt="GIC Rate 3" />
                <div className="card-body bg-danger text-white">
                  <h5>4.25%</h5>
                  <p>On a 5-Year GIC</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer Section */}
      <MDBFooter bgColor='light' className='text-center text-lg-start text-muted'>
        {/* Footer content */}
      </MDBFooter>
    </div>
  );
};

export default Home;
