import React from 'react';
import img1 from './images/img1.jpg'; // Ensure the path is correct
import img2 from './images/img2.jpg'; // Ensure the path is correct

function Home() {
  return (
    <div className="container text-center mt-5">
      <h1 className="display-4 mb-4">Welcome to Our Banking App</h1>
      <p className="lead mb-5">Your gateway to seamless banking services.</p>
      
      <div className="row">
        <div className="col-md-6 mb-4">
          <img src={img1} alt="Banking Service 1" className="img-fluid rounded shadow-lg" />
        </div>
        <div className="col-md-6 mb-4">
          <img src={img2} alt="Banking Service 2" className="img-fluid rounded shadow-lg" />
        </div>
      </div>
    </div>
  );
}

export default Home;
