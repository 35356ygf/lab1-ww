import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link, Navigate } from 'react-router-dom';
import Home from './Home';
import About from './About';
import Login from './Login';
import Transactions from './Transactions';
import Contact from './Contact';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'; // Import your custom CSS file
import logo from './images/logo.png'; // Import your logo

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = () => {
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  return (
    <Router>
      <div className="App">
        {/* Navbar */}
        <nav className="navbar navbar-expand-lg navbar-light bg-light border-bottom fixed-top">
          <div className="container-fluid">
            <Link className="navbar-brand" to="/">
              <img src={logo} alt="Scotiabank Logo" className="navbar-logo" />
            </Link>
            <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                <li className="nav-item">
                  <Link className="nav-link" to="/">Home</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/about">About</Link>
                </li>
                {!isLoggedIn ? (
                  <li className="nav-item">
                    <Link className="nav-link" to="/login">Login</Link>
                  </li>
                ) : (
                  <li className="nav-item">
                    <Link className="nav-link" to="/transactions">Transactions</Link>
                  </li>
                )}
                <li className="nav-item">
                  <Link className="nav-link" to="/contact">Contact Us</Link>
                </li>
              </ul>
              <form className="d-flex ms-auto">
                <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
                <button className="btn btn-danger" type="submit">Search</button>
              </form>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="container mt-4">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route
              path="/login"
              element={<Login onLogin={handleLogin} />}
            />
            <Route
              path="/transactions"
              element={
                isLoggedIn ? <Transactions onLogout={handleLogout} /> : <Navigate to="/login" />
              }
            />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>

        {/* Footer */}
        <footer className="bg-light text-dark py-4 mt-4">
          <div className="container">
            <div className="row">
              <div className="col-md-3 mb-3">
                <p className="mb-0">&copy; 2024 Scotiabank. All rights reserved.</p>
                <p className="mb-0">123 Bank Street, Financial City, FC 12345</p>
                <p className="mb-0">Phone: (123) 456-7890 | Email: info@scotiabank.com</p>
              </div>
              <div className="col-md-3 mb-3">
                <h5>Customer Service</h5>
                <ul className="list-unstyled">
                  <li><a href="#" className="text-dark">FAQ</a></li>
                  <li><a href="#" className="text-dark">Support</a></li>
                  <li><a href="#" className="text-dark">Feedback</a></li>
                </ul>
              </div>
              <div className="col-md-6 mb-3 d-flex align-items-center">
                <div className="w-100">
                  <div className="embed-responsive embed-responsive-16by9">
                    <iframe
                      className="embed-responsive-item"
                      src="https://maps.google.com/maps?q=Financial%20City%2C%20FC%2012345&t=m&z=13&output=embed"
                      width="100%"
                      height="150"
                      style={{ border: 0 }}
                      allowFullScreen=""
                      loading="lazy"
                      title="Map"
                    ></iframe>
                  </div>
                  <div className="text-end mt-2">
                    <p className="mb-0">Find us at:</p>
                    <p className="mb-0"><a href="https://maps.app.goo.gl/gDiD3Ybqv5W5HBTr7" className="text-dark" target="_blank" rel="noopener noreferrer">123 Bank Street, Financial City, FC 12345</a></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;
