// Transaction.js
import React, { useState } from 'react';

const Transaction = ({ onLogout }) => {
  const [accountNumber, setAccountNumber] = useState('');
  const [amount, setAmount] = useState('');
  const [transactions, setTransactions] = useState([]);
  const [balance, setBalance] = useState(0);

  const handleDeposit = () => {
    const amt = parseFloat(amount);
    if (!isNaN(amt) && amt > 0) {
      setBalance(balance + amt);
      const newTransaction = {
        accountNumber,
        amount: amt,
        type: 'Deposit',
        balanceAfter: balance + amt,
      };
      setTransactions([...transactions, newTransaction]);
    }
  };

  const handleWithdraw = () => {
    const amt = parseFloat(amount);
    if (!isNaN(amt) && amt > 0 && amt <= balance) {
      setBalance(balance - amt);
      const newTransaction = {
        accountNumber,
        amount: amt,
        type: 'Withdraw',
        balanceAfter: balance - amt,
      };
      setTransactions([...transactions, newTransaction]);
    }
  };

  return (
    <div className="container mt-5">
      <h1 className="text-center">Transaction Page</h1>
      <button onClick={onLogout} className="btn btn-secondary mb-4">Logout</button>
      <div className="card p-4">
        <h2>Deposit</h2>
        <input
          type="text"
          className="form-control my-2"
          placeholder="Account Number"
          value={accountNumber}
          onChange={(e) => setAccountNumber(e.target.value)}
        />
        <input
          type="number"
          className="form-control my-2"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <div className="d-flex justify-content-between">
          <button className="btn btn-success" onClick={handleDeposit}>Deposit</button>
          <button className="btn btn-secondary">Cancel</button>
        </div>
      </div>

      <h2 className="mt-5">Transaction History</h2>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>Account Number</th>
            <th>Amount</th>
            <th>Type</th>
            <th>Balance After Transaction</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map((transaction, index) => (
            <tr key={index}>
              <td>{transaction.accountNumber}</td>
              <td>{transaction.amount}</td>
              <td>{transaction.type}</td>
              <td>{transaction.balanceAfter}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Transaction;
